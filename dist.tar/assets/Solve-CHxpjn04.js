import{_ as T,o as V,b as c,c as d,d as z,g as n,f as m,F as w,r as N,h as P,e as A,k as _,m as b,z as $,a as g,E as v}from"./index-CYw_2aw5.js";import{r as f}from"./rankStyle-CxzqdHBd.js";const J={class:"solve-page"},O={class:"page-card solve-select"},B={key:0},I={key:1},F={key:2},L={__name:"Solve",setup(M){const i=$({oj:"",grade:""}),h=_(""),p=_(0),y=[{value:"全部",label:"全部"},{value:"2019",label:"2019"},{value:"2023",label:"2023"},{value:"2024",label:"2024"},{value:"2025",label:"2025"}],C=[{value:"cf",label:"Codeforces"},{value:"luogu",label:"洛谷"},{value:"vj",label:"VJudge"}],x={props:["grade"],data(){return{users:[],value:"",tableEmptyText:"没有符合条件的队员",loading:0}},watch:{grade:{handler(l){this.value=l,this.onSubmit()},immediate:!0}},methods:{rankStyle:f,onSubmit(){this.tableEmptyText="查询中......",this.loading=!0,(this.value==""||this.value=="全部")&&(this.value=null),g.getAcCf({grade:this.value}).then(l=>{this.users=l.data.data,this.sortChange({prop:"acNum",order:"descending"}),this.users.forEach(e=>{e.url="https://codeforces.com/profile/"+e.handle}),this.loading=0,this.tableEmptyText="没有符合条件的队员"}).catch(l=>{this.users=null,console.log(l),v.error("请求超时，请重试！"),this.tableEmptyText="查询失败，请重试！",this.loading=0})},sortChange({prop:l,order:e}){this.users.sort(this.compare(l,e));let a=1;this.users.forEach(o=>{o.id=a,a=a+1})},compare(l,e){function a(o){const s=/^\d+(\.\d+)?$/,t=/^(-(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*)))$/;return!!(s.test(o)||t.test(o))}return function(o,s){const t=o[l],r=s[l];return a(t)||a(r)||typeof t=="boolean"&&typeof r=="boolean"?e==="ascending"?t-r:r-t:e==="ascending"?String(t).localeCompare(String(r),"zh"):-String(t).localeCompare(String(r),"zh")}}},template:`
    <div class="table-card">
      <div class="oj-banner oj-cf">Codeforces AC 排行</div>
      <el-table :data="users" style="width: 100%" stripe :empty-text="tableEmptyText" @sort-change="sortChange" :default-sort="{prop:'acNum',order:'descending'}" v-loading="loading">
        <el-table-column prop="id" label="排名" width="80" align="center">
          <template #default="p"><span class="rank-no">{{ p.row.id }}</span></template>
        </el-table-column>
        <el-table-column prop="name" label="队员姓名" min-width="140" />
        <el-table-column prop="handle" label="CF昵称" min-width="160">
          <template #default="p"><a :href="p.row.url" target="_blank">{{ p.row.handle }}</a></template>
        </el-table-column>
        <el-table-column prop="rating" label="分数" sortable="custom" align="center">
          <template #default="p"><b :style="rankStyle(p.row.rating)">{{ p.row.rating }}</b></template>
        </el-table-column>
        <el-table-column prop="acNum" label="AC题数" sortable="custom" align="center">
          <template #default="p"><el-tag type="success">{{ p.row.acNum }}</el-tag></template>
        </el-table-column>
      </el-table>
    </div>`},E={props:["grade"],data(){return{users:[],value:"",tableEmptyText:"没有符合条件的队员",loading:0}},watch:{grade:{handler(l){this.value=l,this.onSubmit()},immediate:!0}},methods:{rankStyle:f,onSubmit(){this.tableEmptyText="查询中......",(this.value==""||this.value=="全部")&&(this.value=null),g.getAcLuogu({grade:this.value}).then(l=>{this.users=l.data.data,this.users.sort(this.cmp),this.sortChange({prop:"acNum",order:"descending"}),this.users.forEach(e=>{e.url="https://www.luogu.com.cn/user/"+e.lgid,e.acNum1=e.solves[0].problemNum,e.acNum2=e.solves[1].problemNum,e.acNum3=e.solves[2].problemNum,e.acNum4=e.solves[3].problemNum,e.acNum5=e.solves[4].problemNum,e.acNum6=e.solves[5].problemNum,e.acNum7=e.solves[6].problemNum,e.acNum8=e.solves[7].problemNum}),this.tableEmptyText="没有符合条件的队员"}).catch(l=>{this.users=null,console.log(l),v.error("请求超时，请重试！"),this.tableEmptyText="查询失败，请重试！"})},cmp(l,e){return l.acNum>e.acNum},sortChange({prop:l,order:e}){this.users.sort(this.compare(l,e));let a=1;this.users.forEach(o=>{o.id=a,a=a+1})},compare(l,e){function a(o){const s=/^\d+(\.\d+)?$/,t=/^(-(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*)))$/;return!!(s.test(o)||t.test(o))}return function(o,s){const t=o[l],r=s[l];return a(t)||a(r)?e==="ascending"?t-r:r-t:e==="ascending"?String(t).localeCompare(String(r),"zh"):-String(t).localeCompare(String(r),"zh")}}},template:`
    <div class="table-card">
      <div class="oj-banner oj-luogu">洛谷 AC 排行</div>
      <el-table :data="users" style="width: 100%" stripe :empty-text="tableEmptyText" @sort-change="sortChange" :default-sort="{prop:'acNum',order:'descending'}">
        <el-table-column prop="id" label="排名" width="70" align="center">
          <template #default="p"><span class="rank-no">{{ p.row.id }}</span></template>
        </el-table-column>
        <el-table-column prop="name" label="队员姓名" min-width="110" />
        <el-table-column prop="lgid" label="洛谷id" width="100">
          <template #default="p"><a :href="p.row.url" target="_blank">{{ p.row.lgid }}</a></template>
        </el-table-column>
        <el-table-column prop="acNum1" label="暂无评定" width="90" align="center" />
        <el-table-column prop="acNum2" label="入门" width="80" align="center" />
        <el-table-column prop="acNum3" label="普及-" width="80" align="center" />
        <el-table-column prop="acNum4" label="普及/提高-" width="100" align="center" />
        <el-table-column prop="acNum5" label="普及+/提高" width="100" align="center" />
        <el-table-column prop="acNum6" label="提高+/省选" width="100" align="center" />
        <el-table-column prop="acNum7" label="省选/NOI-" width="100" align="center" />
        <el-table-column prop="acNum8" label="NOI/NOI+/CTSC" width="110" align="center" />
        <el-table-column prop="acNum" label="总题数" sortable="custom" align="center">
          <template #default="p"><el-tag type="success">{{ p.row.acNum }}</el-tag></template>
        </el-table-column>
      </el-table>
    </div>`},S={props:["grade"],data(){return{users:[],value:"",tableEmptyText:"没有符合条件的队员",loading:0}},watch:{grade:{handler(l){this.value=l,this.onSubmit()},immediate:!0}},methods:{rankStyle:f,onSubmit(){this.tableEmptyText="查询中......",this.loading=!0,(this.value==""||this.value=="全部")&&(this.value=null),g.getAcVj({grade:this.value}).then(l=>{console.log(l),this.users=l.data.data,this.users.sort(this.cmp),this.sortChange({prop:"totalProblem",order:"descending"}),this.users.forEach(e=>{e.url="https://vjudge.csgrandeur.cn/user/"+e.vjName}),this.tableEmptyText="没有符合条件的队员",this.loading=0}).catch(l=>{this.users=null,console.log(l),v.error("请求超时，请重试！"),this.tableEmptyText="查询失败，请重试！",this.loading=0})},cmp(l,e){return l.totalProblem>e.totalProblem},sortChange({prop:l,order:e}){this.users.sort(this.compare(l,e));let a=1;this.users.forEach(o=>{o.id=a,a=a+1})},compare(l,e){function a(o){const s=/^\d+(\.\d+)?$/,t=/^(-(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*)))$/;return!!(s.test(o)||t.test(o))}return function(o,s){const t=o[l],r=s[l];return a(t)||a(r)?e==="ascending"?t-r:r-t:e==="ascending"?String(t).localeCompare(String(r),"zh"):-String(t).localeCompare(String(r),"zh")}}},template:`
    <div class="table-card">
      <div class="oj-banner oj-vj">VJudge AC 排行</div>
      <el-table :data="users" style="width: 100%" stripe :empty-text="tableEmptyText" @sort-change="sortChange" :default-sort="{prop:'totalProblem',order:'descending'}" v-loading="loading">
        <el-table-column prop="id" label="排名" width="80" align="center">
          <template #default="p"><span class="rank-no">{{ p.row.id }}</span></template>
        </el-table-column>
        <el-table-column prop="name" label="队员姓名" min-width="130" />
        <el-table-column prop="vjName" label="VJ账号" min-width="150">
          <template #default="p"><a :href="p.row.url" target="_blank">{{ p.row.vjName }}</a></template>
        </el-table-column>
        <el-table-column prop="weekProblem" label="7日内做题" width="110" sortable="custom" align="center">
          <template #default="p"><el-tag type="warning" effect="plain">{{ p.row.weekProblem }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="monthProblem" label="30日内做题" width="110" sortable="custom" align="center">
          <template #default="p"><el-tag type="info" effect="plain">{{ p.row.monthProblem }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="totalProblem" label="总题量" sortable="custom" align="center">
          <template #default="p"><el-tag type="success">{{ p.row.totalProblem }}</el-tag></template>
        </el-table-column>
      </el-table>
    </div>`};function k(){h.value=i.grade,i.oj=="cf"?p.value=1:i.oj=="luogu"?p.value=2:i.oj=="vj"&&(p.value=3)}return V(()=>{h.value="全部"}),(l,e)=>{const a=b("el-option"),o=b("el-select"),s=b("el-form-item"),t=b("el-button"),r=b("el-form"),j=b("el-empty");return c(),d("div",J,[z("div",O,[n(r,{model:i,inline:""},{default:m(()=>[n(s,{label:"OJ"},{default:m(()=>[n(o,{modelValue:i.oj,"onUpdate:modelValue":e[0]||(e[0]=u=>i.oj=u),size:"large",style:{width:"180px"}},{default:m(()=>[(c(),d(w,null,N(C,u=>n(a,{key:u.value,label:u.label,value:u.value},null,8,["label","value"])),64))]),_:1},8,["modelValue"])]),_:1}),n(s,{label:"年级"},{default:m(()=>[n(o,{modelValue:i.grade,"onUpdate:modelValue":e[1]||(e[1]=u=>i.grade=u),size:"large",style:{width:"140px"}},{default:m(()=>[(c(),d(w,null,N(y,u=>n(a,{key:u.value,label:u.label,value:u.value},null,8,["label","value"])),64))]),_:1},8,["modelValue"])]),_:1}),n(s,null,{default:m(()=>[n(t,{type:"primary",size:"large",onClick:k},{default:m(()=>[...e[2]||(e[2]=[P("查 询",-1)])]),_:1})]),_:1})]),_:1},8,["model"])]),p.value==1?(c(),d("div",B,[n(x,{grade:h.value},null,8,["grade"])])):p.value==2?(c(),d("div",I,[n(E,{grade:h.value},null,8,["grade"])])):p.value==3?(c(),d("div",F,[n(S,{grade:h.value},null,8,["grade"])])):(c(),A(j,{key:3,description:"请选择 OJ 与年级后查询"}))])}}},D=T(L,[["__scopeId","data-v-0d46b25f"]]);export{D as default};
